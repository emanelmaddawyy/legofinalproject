import { Form} from 'react-bootstrap';

const { Component } = require("react");
class LoginPage extends Component{
  render(){
    return(<>
    
    <Form>
       <input type="text"/>
    </Form></>)
  }
}
export default LoginPage;