import { Component } from 'react';
import Header from '../components/Header/Header';

class HomePage extends Component {

  render() {
    return(
      <Header/>
    )
  }
}
export default HomePage