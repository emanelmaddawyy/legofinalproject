import TopHeader from "./TopHeader";
import './Header.css'

const { Component } = require("react");

export default class Header extends Component{
  render(){
    return(
      <TopHeader/>
    )
  }
}
